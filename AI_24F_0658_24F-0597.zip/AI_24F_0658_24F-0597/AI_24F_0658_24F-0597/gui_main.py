

import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import pygame

try:
    from grid_model import Grid, EMPTY, WALL, START, TARGET, FRONTIER, EXPLORED, PATH, DYNAMIC_OBSTACLE
    from algorithms import SearchAlgorithms
except ImportError as e:
    print(f"ERROR: Could not import required modules: {e}")
    print("\nMake sure these files are in the same directory:")
    print("  - grid_model.py")
    print("  - algorithms.py")
    print("  - gui_main.py")
    sys.exit(1)

pygame.init()

info = pygame.display.Info()
WINDOW_WIDTH = info.current_w
WINDOW_HEIGHT = info.current_h

GRID_COLS = 40
GRID_ROWS = 25
CELL_SIZE = min((WINDOW_WIDTH - 400) // GRID_COLS, (WINDOW_HEIGHT - 100) // GRID_ROWS)

INFO_PANEL_WIDTH = 350

BG_COLOR = (15, 23, 42)          
GRID_BG = (30, 41, 59)          
GRID_LINE = (51, 65, 85)         
PANEL_BG = (30, 41, 59)         


START_COLOR = (34, 197, 94)      
TARGET_COLOR = (239, 68, 68)      
WALL_COLOR = (71, 85, 105)        
FRONTIER_COLOR = (234, 179, 8)  
EXPLORED_COLOR = (59, 130, 246)   
PATH_COLOR = (168, 85, 247)     
DYNAMIC_COLOR = (249, 115, 22)

# UI colors
TEXT_COLOR = (226, 232, 240)     
ACCENT_COLOR = (56, 189, 248)  
YELLOW_TEXT = (234, 179, 8)      
PURPLE_TEXT = (168, 85, 247)     
HEADER_COLOR = (56, 189, 248)  


class PathfinderGUI:
   
    
    def __init__(self):
        try:
            self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.FULLSCREEN)
            pygame.display.set_caption("AI Pathfinder - Visual Search Algorithms")
            self.clock = pygame.time.Clock()
        except Exception as e:
            print(f"ERROR: Could not initialize display: {e}")
            pygame.quit()
            sys.exit(1)
        
        
        self.grid = Grid(GRID_ROWS, GRID_COLS)
        
       
        self.searching = False
        self.speed = 30  
        self.selected_algorithm = 'BFS'
        self.mode = 'start'  
        
      
        self.nodes_explored = 0
        self.path_length = 0
        self.search_complete = False
        self.status = "READY"
        
       
        try:
            self.font_title = pygame.font.Font(None, 56)
            self.font_large = pygame.font.Font(None, 40)
            self.font_medium = pygame.font.Font(None, 32)
            self.font_small = pygame.font.Font(None, 26)
        except Exception as e:
            print(f"ERROR: Could not load fonts: {e}")
            pygame.quit()
            sys.exit(1)
        
       
        self.grid_width = GRID_COLS * CELL_SIZE
        self.grid_height = GRID_ROWS * CELL_SIZE
        self.grid_x = (WINDOW_WIDTH - INFO_PANEL_WIDTH - self.grid_width) // 2
        self.grid_y = (WINDOW_HEIGHT - self.grid_height) // 2
    
    def get_color_for_state(self, state):
      
        color_map = {
            EMPTY: GRID_BG,
            WALL: WALL_COLOR,
            START: START_COLOR,
            TARGET: TARGET_COLOR,
            FRONTIER: FRONTIER_COLOR,
            EXPLORED: EXPLORED_COLOR,
            PATH: PATH_COLOR,
            DYNAMIC_OBSTACLE: DYNAMIC_COLOR
        }
        return color_map.get(state, GRID_BG)
    
    def draw_grid(self):
     
        try:
      
            pygame.draw.rect(self.screen, GRID_BG, 
                            (self.grid_x - 10, self.grid_y - 10, 
                             self.grid_width + 20, self.grid_height + 20),
                            border_radius=12)
            
            for row in range(self.grid.rows):
                for col in range(self.grid.cols):
                    node = self.grid.grid[row][col]
                    x = self.grid_x + col * CELL_SIZE
                    y = self.grid_y + row * CELL_SIZE
                    
                    color = self.get_color_for_state(node.state)
                    
                 
                    padding = 1
                    pygame.draw.rect(self.screen, color,
                                   (x + padding, y + padding, 
                                    CELL_SIZE - padding*2, CELL_SIZE - padding*2),
                                   border_radius=2)
                 
                    if node.state == EMPTY:
                        pygame.draw.rect(self.screen, GRID_LINE,
                                       (x + padding, y + padding,
                                        CELL_SIZE - padding*2, CELL_SIZE - padding*2),
                                       1, border_radius=2)
        except Exception as e:
            print(f"Error drawing grid: {e}")
    
    def draw_info_panel(self):
       
        try:
            panel_x = WINDOW_WIDTH - INFO_PANEL_WIDTH + 30
            panel_y = 80
            
        
            title = self.font_title.render("AI PATHFINDER", True, HEADER_COLOR)
            self.screen.blit(title, (panel_x, panel_y))
            panel_y += 80
            
    
            algo_label = self.font_small.render("ALGORITHM", True, TEXT_COLOR)
            self.screen.blit(algo_label, (panel_x, panel_y))
            panel_y += 35
            
            algo_name = self.font_large.render(self.selected_algorithm, True, ACCENT_COLOR)
            self.screen.blit(algo_name, (panel_x, panel_y))
            panel_y += 70
            
    
            box_width = INFO_PANEL_WIDTH - 60
            box_height = 140
            pygame.draw.rect(self.screen, GRID_BG,
                            (panel_x, panel_y, box_width, box_height),
                            border_radius=10)
            pygame.draw.rect(self.screen, ACCENT_COLOR,
                            (panel_x, panel_y, box_width, box_height),
                            2, border_radius=10)
         
            stats_y = panel_y + 20
            nodes_text = self.font_medium.render(f"Nodes: {self.nodes_explored}", True, TEXT_COLOR)
            self.screen.blit(nodes_text, (panel_x + 20, stats_y))
            
            stats_y += 40
            path_text = self.font_medium.render(f"Path: {self.path_length}", True, TEXT_COLOR)
            self.screen.blit(path_text, (panel_x + 20, stats_y))
            
            stats_y += 40
            status_color = PURPLE_TEXT if self.search_complete else (YELLOW_TEXT if self.searching else START_COLOR)
            status_text = self.font_medium.render(f"Status: {self.status}", True, status_color)
            self.screen.blit(status_text, (panel_x + 20, stats_y))
            
            panel_y += box_height + 50
            
          
            controls_title = self.font_large.render("CONTROLS", True, HEADER_COLOR)
            self.screen.blit(controls_title, (panel_x, panel_y))
            panel_y += 50
            
            controls = [
                ("1-6", "Select Algorithm"),
                ("SPACE", "Start Search"),
                ("R", "Reset Search"),
                ("C", "Clear Grid"),
                ("+/-", f"Speed ({self.speed}ms)"),
                ("ESC", "Exit")
            ]
            
            for key, desc in controls:
                key_text = self.font_small.render(key, True, YELLOW_TEXT)
                desc_text = self.font_small.render(desc, True, TEXT_COLOR)
                self.screen.blit(key_text, (panel_x, panel_y))
                self.screen.blit(desc_text, (panel_x + 100, panel_y))
                panel_y += 35
            
            panel_y += 30
         
            legend_title = self.font_large.render("LEGEND", True, HEADER_COLOR)
            self.screen.blit(legend_title, (panel_x, panel_y))
            panel_y += 50
            
            legend_items = [
                ("Start", START_COLOR),
                ("Target", TARGET_COLOR),
                ("Wall", WALL_COLOR),
                ("Frontier", FRONTIER_COLOR),
                ("Explored", EXPLORED_COLOR),
                ("Path", PATH_COLOR),
                ("Dynamic", DYNAMIC_COLOR)
            ]
            
            for label, color in legend_items:
                pygame.draw.circle(self.screen, color, (panel_x + 12, panel_y + 12), 10)
                text = self.font_small.render(label, True, TEXT_COLOR)
                self.screen.blit(text, (panel_x + 35, panel_y + 2))
                panel_y += 35
        except Exception as e:
            print(f"Error drawing info panel: {e}")
    
    def handle_mouse_click(self, pos):
       
        if self.searching:
            return
        
        try:
           
            col = (pos[0] - self.grid_x) // CELL_SIZE
            row = (pos[1] - self.grid_y) // CELL_SIZE
            
            if 0 <= row < self.grid.rows and 0 <= col < self.grid.cols:
                if self.mode == 'start':
                    self.grid.set_start(row, col)
                    self.mode = 'target'
                elif self.mode == 'target':
                    if (row, col) != self.grid.start:
                        self.grid.set_target(row, col)
                        self.mode = 'wall'
                elif self.mode == 'wall':
                    if (row, col) != self.grid.start and (row, col) != self.grid.target:
                        self.grid.toggle_wall(row, col)
        except Exception as e:
            print(f"Error handling mouse click: {e}")
    
    def visualization_callback(self, action, data):
       
        try:
        
            for event in pygame.event.get():
                if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                    self.searching = False
                    return False
            
            if action == 'explore':
                node = data
                if node.state not in [START, TARGET]:
                    node.state = EXPLORED
            
            elif action == 'frontier':
                node = data
                if node.state not in [START, TARGET]:
                    node.state = FRONTIER
            
            elif action == 'depth_update':
                depth = data
                self.status = f"IDDFS: Depth {depth}"
            
        
            obstacle = self.grid.add_dynamic_obstacle()
            
         
            self.screen.fill(BG_COLOR)
            self.draw_grid()
            self.draw_info_panel()
            pygame.display.flip()
            pygame.time.delay(self.speed)
            
            return self.searching
        except Exception as e:
            print(f"Error in visualization callback: {e}")
            return False
    
    def mark_path(self, path):
    
        try:
            if path:
                for pos in path:
                    node = self.grid.get_node(pos[0], pos[1])
                    if node and node.state not in [START, TARGET]:
                        node.state = PATH
        except Exception as e:
            print(f"Error marking path: {e}")
    
    def start_search(self):
    
        if self.searching or not self.grid.start or not self.grid.target:
            return
        
        try:
            self.searching = True
            self.search_complete = False
            self.nodes_explored = 0
            self.path_length = 0
            self.status = "SEARCHING..."
            self.grid.reset_search_states()
            
            result = None
            
            if self.selected_algorithm == 'BFS':
                result = SearchAlgorithms.bfs(self.grid, self.grid.start, self.grid.target, 
                                             self.visualization_callback)
            
            elif self.selected_algorithm == 'DFS':
                result = SearchAlgorithms.dfs(self.grid, self.grid.start, self.grid.target, 
                                             self.visualization_callback)
            
            elif self.selected_algorithm == 'UCS':
                result = SearchAlgorithms.ucs(self.grid, self.grid.start, self.grid.target, 
                                             self.visualization_callback)
            
            elif self.selected_algorithm == 'DLS':
                result = SearchAlgorithms.dls(self.grid, self.grid.start, self.grid.target, 
                                             depth_limit=10, callback=self.visualization_callback)
            
            elif self.selected_algorithm == 'IDDFS':
                result = SearchAlgorithms.iddfs(self.grid, self.grid.start, self.grid.target, 
                                               max_depth=50, callback=self.visualization_callback)
            
            elif self.selected_algorithm == 'Bidirectional':
                result = SearchAlgorithms.bidirectional(self.grid, self.grid.start, self.grid.target, 
                                                       self.visualization_callback)
           
            if result:
                path, nodes_explored, success = result
                self.nodes_explored = nodes_explored
                if success and path:
                    self.mark_path(path)
                    self.path_length = len(path)
                    self.status = "COMPLETE"
                    self.search_complete = True
                else:
                    self.status = "NO PATH"
            
            self.searching = False
        except Exception as e:
            print(f"Error during search: {e}")
            self.searching = False
            self.status = "ERROR"
    
    def reset(self):
       
        try:
            self.searching = False
            self.search_complete = False
            self.nodes_explored = 0
            self.path_length = 0
            self.status = "READY"
            self.grid.reset_search_states()
        except Exception as e:
            print(f"Error resetting: {e}")
    
    def clear_grid(self):
      
        try:
            self.grid.clear()
            self.searching = False
            self.search_complete = False
            self.nodes_explored = 0
            self.path_length = 0
            self.status = "READY"
            self.mode = 'start'
        except Exception as e:
            print(f"Error clearing grid: {e}")
    
    def run(self):
       
        running = True
        
        print("\n" + "="*50)
        print("AI PATHFINDER - Started Successfully!")
        print("="*50)
        print("\nControls:")
        print("  1-6: Select Algorithm")
        print("  SPACE: Start Search")
        print("  R: Reset")
        print("  C: Clear Grid")
        print("  ESC: Exit\n")
        
        try:
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            running = False
                        elif event.key == pygame.K_SPACE:
                            self.start_search()
                        elif event.key == pygame.K_r:
                            self.reset()
                        elif event.key == pygame.K_c:
                            self.clear_grid()
                        elif event.key == pygame.K_1:
                            self.selected_algorithm = 'BFS'
                        elif event.key == pygame.K_2:
                            self.selected_algorithm = 'DFS'
                        elif event.key == pygame.K_3:
                            self.selected_algorithm = 'UCS'
                        elif event.key == pygame.K_4:
                            self.selected_algorithm = 'DLS'
                        elif event.key == pygame.K_5:
                            self.selected_algorithm = 'IDDFS'
                        elif event.key == pygame.K_6:
                            self.selected_algorithm = 'Bidirectional'
                        elif event.key == pygame.K_EQUALS or event.key == pygame.K_PLUS:
                            self.speed = max(5, self.speed - 5)
                        elif event.key == pygame.K_MINUS:
                            self.speed = min(100, self.speed + 5)
                    
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        self.handle_mouse_click(pygame.mouse.get_pos())
            
                self.screen.fill(BG_COLOR)
                self.draw_grid()
                self.draw_info_panel()
                pygame.display.flip()
                self.clock.tick(60)
        
        except KeyboardInterrupt:
            print("\nExiting...")
        except Exception as e:
            print(f"\nError in main loop: {e}")
            import traceback
            traceback.print_exc()
        finally:
            pygame.quit()
            sys.exit()


if __name__ == "__main__":
    try:
        gui = PathfinderGUI()
        gui.run()
    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)