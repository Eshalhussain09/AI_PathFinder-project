import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import pygame

try:
    from grid_model import Grid, EMPTY, START, TARGET, FRONTIER, EXPLORED, PATH
    from algorithms import SearchAlgorithms
except ImportError as e:
    print(f"ERROR: Could not import required modules: {e}")
    print("\nMake sure these files are in the same directory:")
    print("  - grid_model.py")
    print("  - algorithms.py")
    print("  - gui_main.py")
    sys.exit(1)

pygame.init()

info = pygame.display.Info()
WINDOW_WIDTH = info.current_w
WINDOW_HEIGHT = info.current_h

# --- Layout constants ---
INFO_PANEL_WIDTH = 320
MARGIN = 20          # padding around the grid
TOP_BAR = 20         # space at top
BOTTOM_BAR = 20      # space at bottom

GRID_COLS = 40
GRID_ROWS = 25

available_w = WINDOW_WIDTH - INFO_PANEL_WIDTH - MARGIN * 3
available_h = WINDOW_HEIGHT - TOP_BAR - BOTTOM_BAR

CELL_SIZE = min(available_w // GRID_COLS, available_h // GRID_ROWS)

# Colors
BG_COLOR        = (15, 23, 42)
GRID_BG         = (30, 41, 59)
GRID_LINE       = (51, 65, 85)
PANEL_BG        = (30, 41, 59)
START_COLOR     = (34, 197, 94)
TARGET_COLOR    = (239, 68, 68)
FRONTIER_COLOR  = (234, 179, 8)
EXPLORED_COLOR  = (59, 130, 246)
PATH_COLOR      = (168, 85, 247)
TEXT_COLOR      = (226, 232, 240)
ACCENT_COLOR    = (56, 189, 248)
YELLOW_TEXT     = (234, 179, 8)
PURPLE_TEXT     = (168, 85, 247)
HEADER_COLOR    = (56, 189, 248)


class PathfinderGUI:

    def __init__(self):
        try:
            self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.FULLSCREEN)
            pygame.display.set_caption("AI Pathfinder - Visual Search Algorithms")
            self.clock = pygame.time.Clock()
        except Exception as e:
            print(f"ERROR: Could not initialize display: {e}")
            pygame.quit()
            sys.exit(1)

        self.grid = Grid(GRID_ROWS, GRID_COLS)

        self.searching = False
        self.speed = 30
        self.selected_algorithm = 'BFS'
        self.mode = 'start'

        self.nodes_explored = 0
        self.path_length = 0
        self.search_complete = False
        self.status = "READY"

        try:
            self.font_title  = pygame.font.Font(None, 42)
            self.font_large  = pygame.font.Font(None, 34)
            self.font_medium = pygame.font.Font(None, 28)
            self.font_small  = pygame.font.Font(None, 24)
        except Exception as e:
            print(f"ERROR: Could not load fonts: {e}")
            pygame.quit()
            sys.exit(1)

        # Grid pixel dimensions
        self.grid_width  = GRID_COLS * CELL_SIZE
        self.grid_height = GRID_ROWS * CELL_SIZE

        # Centre the grid in the left portion of the screen (excluding the panel)
        left_area_width = WINDOW_WIDTH - INFO_PANEL_WIDTH - MARGIN
        self.grid_x = (left_area_width - self.grid_width) // 2
        self.grid_y = (WINDOW_HEIGHT - self.grid_height) // 2

        # Info panel starts just past the grid area
        self.panel_x = WINDOW_WIDTH - INFO_PANEL_WIDTH

    def get_color_for_state(self, state):
        color_map = {
            EMPTY:    GRID_BG,
            START:    START_COLOR,
            TARGET:   TARGET_COLOR,
            FRONTIER: FRONTIER_COLOR,
            EXPLORED: EXPLORED_COLOR,
            PATH:     PATH_COLOR,
        }
        return color_map.get(state, GRID_BG)

    def draw_grid(self):
        try:
            pygame.draw.rect(self.screen, GRID_BG,
                             (self.grid_x - 8, self.grid_y - 8,
                              self.grid_width + 16, self.grid_height + 16),
                             border_radius=10)

            for row in range(self.grid.rows):
                for col in range(self.grid.cols):
                    node  = self.grid.grid[row][col]
                    x     = self.grid_x + col * CELL_SIZE
                    y     = self.grid_y + row * CELL_SIZE
                    color = self.get_color_for_state(node.state)
                    pad   = 1

                    pygame.draw.rect(self.screen, color,
                                     (x + pad, y + pad,
                                      CELL_SIZE - pad * 2, CELL_SIZE - pad * 2),
                                     border_radius=2)

                    if node.state == EMPTY:
                        pygame.draw.rect(self.screen, GRID_LINE,
                                         (x + pad, y + pad,
                                          CELL_SIZE - pad * 2, CELL_SIZE - pad * 2),
                                         1, border_radius=2)
        except Exception as e:
            print(f"Error drawing grid: {e}")

    def draw_info_panel(self):
        try:
            px = self.panel_x + 16   # left edge of content inside panel
            py = 16                  # current vertical cursor
            line_gap = 4             # extra gap between sections

            # --- Background strip for the panel ---
            pygame.draw.rect(self.screen, PANEL_BG,
                             (self.panel_x, 0, INFO_PANEL_WIDTH, WINDOW_HEIGHT))

            # Title
            title = self.font_title.render("AI PATHFINDER", True, HEADER_COLOR)
            self.screen.blit(title, (px, py))
            py += title.get_height() + line_gap + 6

            # Algorithm label + name
            lbl = self.font_small.render("ALGORITHM", True, TEXT_COLOR)
            self.screen.blit(lbl, (px, py))
            py += lbl.get_height() + 2

            algo = self.font_large.render(self.selected_algorithm, True, ACCENT_COLOR)
            self.screen.blit(algo, (px, py))
            py += algo.get_height() + line_gap + 6

            # Stats box
            box_w = INFO_PANEL_WIDTH - 32
            box_h = 110
            pygame.draw.rect(self.screen, GRID_BG,   (px, py, box_w, box_h), border_radius=8)
            pygame.draw.rect(self.screen, ACCENT_COLOR, (px, py, box_w, box_h), 2, border_radius=8)

            sy = py + 12
            self.screen.blit(self.font_medium.render(f"Nodes: {self.nodes_explored}", True, TEXT_COLOR), (px + 14, sy))
            sy += 32
            self.screen.blit(self.font_medium.render(f"Path:  {self.path_length}", True, TEXT_COLOR), (px + 14, sy))
            sy += 32
            sc = PURPLE_TEXT if self.search_complete else (YELLOW_TEXT if self.searching else START_COLOR)
            self.screen.blit(self.font_medium.render(f"Status: {self.status}", True, sc), (px + 14, sy))

            py += box_h + line_gap + 10

            # Controls
            self.screen.blit(self.font_large.render("CONTROLS", True, HEADER_COLOR), (px, py))
            py += self.font_large.get_height() + 4

            controls = [
                ("1-6",    "Select Algorithm"),
                ("SPACE",  "Start Search"),
                ("R",      "Reset Search"),
                ("C",      "Clear Grid"),
                ("+/-",    f"Speed ({self.speed}ms)"),
                ("ESC",    "Exit"),
            ]
            for key, desc in controls:
                self.screen.blit(self.font_small.render(key,  True, YELLOW_TEXT), (px, py))
                self.screen.blit(self.font_small.render(desc, True, TEXT_COLOR),  (px + 85, py))
                py += self.font_small.get_height() + 3

            py += line_gap + 8

            # Legend
            self.screen.blit(self.font_large.render("LEGEND", True, HEADER_COLOR), (px, py))
            py += self.font_large.get_height() + 4

            legend_items = [
                ("Start",    START_COLOR),
                ("Target",   TARGET_COLOR),
                ("Frontier", FRONTIER_COLOR),
                ("Explored", EXPLORED_COLOR),
                ("Path",     PATH_COLOR),
            ]
            for label, color in legend_items:
                pygame.draw.circle(self.screen, color, (px + 10, py + 10), 8)
                self.screen.blit(self.font_small.render(label, True, TEXT_COLOR), (px + 28, py + 2))
                py += self.font_small.get_height() + 3

            # Mode hint at the bottom (only if it fits)
            mode_hints = {
                'start':  "Click to place START",
                'target': "Click to place TARGET",
                'done':   "",
            }
            hint = mode_hints.get(self.mode, "")
            hint_surf = self.font_small.render(hint, True, ACCENT_COLOR)
            hint_y = WINDOW_HEIGHT - hint_surf.get_height() - 12
            if hint_y > py:
                self.screen.blit(hint_surf, (px, hint_y))

        except Exception as e:
            print(f"Error drawing info panel: {e}")

    def handle_mouse_click(self, pos):
        if self.searching:
            return
        try:
            col = (pos[0] - self.grid_x) // CELL_SIZE
            row = (pos[1] - self.grid_y) // CELL_SIZE

            if 0 <= row < self.grid.rows and 0 <= col < self.grid.cols:
                if self.mode == 'start':
                    self.grid.set_start(row, col)
                    self.mode = 'target'
                elif self.mode == 'target':
                    if (row, col) != self.grid.start:
                        self.grid.set_target(row, col)
                        self.mode = 'done'
        except Exception as e:
            print(f"Error handling mouse click: {e}")

    def visualization_callback(self, action, data):
        try:
            for event in pygame.event.get():
                if event.type == pygame.QUIT or (
                        event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                    self.searching = False
                    return False

            if action == 'explore':
                node = data
                if node.state not in [START, TARGET]:
                    node.state = EXPLORED
            elif action == 'frontier':
                node = data
                if node.state not in [START, TARGET]:
                    node.state = FRONTIER
            elif action == 'depth_update':
                self.status = f"IDDFS: Depth {data}"

            self.screen.fill(BG_COLOR)
            self.draw_grid()
            self.draw_info_panel()
            pygame.display.flip()
            pygame.time.delay(self.speed)

            return self.searching
        except Exception as e:
            print(f"Error in visualization callback: {e}")
            return False

    def mark_path(self, path):
        try:
            if path:
                for pos in path:
                    node = self.grid.get_node(pos[0], pos[1])
                    if node and node.state not in [START, TARGET]:
                        node.state = PATH
        except Exception as e:
            print(f"Error marking path: {e}")

    def start_search(self):
        if self.searching or not self.grid.start or not self.grid.target:
            return
        try:
            self.searching = True
            self.search_complete = False
            self.nodes_explored = 0
            self.path_length = 0
            self.status = "SEARCHING..."
            self.grid.reset_search_states()

            result = None

            if self.selected_algorithm == 'BFS':
                result = SearchAlgorithms.bfs(self.grid, self.grid.start, self.grid.target,
                                              self.visualization_callback)
            elif self.selected_algorithm == 'DFS':
                result = SearchAlgorithms.dfs(self.grid, self.grid.start, self.grid.target,
                                              self.visualization_callback)
            elif self.selected_algorithm == 'UCS':
                result = SearchAlgorithms.ucs(self.grid, self.grid.start, self.grid.target,
                                              self.visualization_callback)
            elif self.selected_algorithm == 'DLS':
                result = SearchAlgorithms.dls(self.grid, self.grid.start, self.grid.target,
                                              depth_limit=10, callback=self.visualization_callback)
            elif self.selected_algorithm == 'IDDFS':
                result = SearchAlgorithms.iddfs(self.grid, self.grid.start, self.grid.target,
                                                max_depth=50, callback=self.visualization_callback)
            elif self.selected_algorithm == 'Bidirectional':
                result = SearchAlgorithms.bidirectional(self.grid, self.grid.start, self.grid.target,
                                                        self.visualization_callback)

            if result:
                path, nodes_explored, success = result
                self.nodes_explored = nodes_explored
                if success and path:
                    self.mark_path(path)
                    self.path_length = len(path)
                    self.status = "COMPLETE"
                    self.search_complete = True
                else:
                    self.status = "NO PATH"

            self.searching = False
        except Exception as e:
            print(f"Error during search: {e}")
            self.searching = False
            self.status = "ERROR"

    def reset(self):
        try:
            self.searching = False
            self.search_complete = False
            self.nodes_explored = 0
            self.path_length = 0
            self.status = "READY"
            self.grid.reset_search_states()
        except Exception as e:
            print(f"Error resetting: {e}")

    def clear_grid(self):
        try:
            self.grid.clear()
            self.searching = False
            self.search_complete = False
            self.nodes_explored = 0
            self.path_length = 0
            self.status = "READY"
            self.mode = 'start'
        except Exception as e:
            print(f"Error clearing grid: {e}")

    def run(self):
        running = True
        print("\n" + "=" * 50)
        print("AI PATHFINDER - Started Successfully!")
        print("=" * 50)
        print(f"Screen:    {WINDOW_WIDTH} x {WINDOW_HEIGHT}")
        print(f"Cell size: {CELL_SIZE}px   Grid area: {self.grid_width} x {self.grid_height}")
        print(f"Grid pos:  ({self.grid_x}, {self.grid_y})")
        print("\nControls:")
        print("  1-6: Select Algorithm | SPACE: Start | R: Reset | C: Clear | ESC: Exit\n")

        try:
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False

                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_ESCAPE:
                            running = False
                        elif event.key == pygame.K_SPACE:
                            self.start_search()
                        elif event.key == pygame.K_r:
                            self.reset()
                        elif event.key == pygame.K_c:
                            self.clear_grid()
                        elif event.key == pygame.K_1:
                            self.selected_algorithm = 'BFS'
                        elif event.key == pygame.K_2:
                            self.selected_algorithm = 'DFS'
                        elif event.key == pygame.K_3:
                            self.selected_algorithm = 'UCS'
                        elif event.key == pygame.K_4:
                            self.selected_algorithm = 'DLS'
                        elif event.key == pygame.K_5:
                            self.selected_algorithm = 'IDDFS'
                        elif event.key == pygame.K_6:
                            self.selected_algorithm = 'Bidirectional'
                        elif event.key in (pygame.K_EQUALS, pygame.K_PLUS):
                            self.speed = max(5, self.speed - 5)
                        elif event.key == pygame.K_MINUS:
                            self.speed = min(100, self.speed + 5)

                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        self.handle_mouse_click(pygame.mouse.get_pos())

                self.screen.fill(BG_COLOR)
                self.draw_grid()
                self.draw_info_panel()
                pygame.display.flip()
                self.clock.tick(60)

        except KeyboardInterrupt:
            print("\nExiting...")
        except Exception as e:
            print(f"\nError in main loop: {e}")
            import traceback
            traceback.print_exc()
        finally:
            pygame.quit()
            sys.exit()


if __name__ == "__main__":
    try:
        gui = PathfinderGUI()
        gui.run()
    except Exception as e:
        print(f"\nFATAL ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)