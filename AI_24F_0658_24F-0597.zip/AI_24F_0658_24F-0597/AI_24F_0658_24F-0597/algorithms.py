from collections import deque
from queue import PriorityQueue

class SearchAlgorithms:
    @staticmethod
    def bfs(grid, start, target, callback=None):
        queue = deque()
        visited = set()
        parent_map = {}
        
        start_node = grid.grid[start[0]][start[1]]
        queue.append(start_node)
        visited.add((start_node.row, start_node.col))
        parent_map[(start_node.row, start_node.col)] = None
        
        nodes_explored = 0
        
        while queue:
            current = queue.popleft()
            nodes_explored += 1
            
            if callback:
                should_continue = callback('explore', current)
                if not should_continue:
                    return None, nodes_explored, False
            
            if (current.row, current.col) == target:
                path = SearchAlgorithms._reconstruct_path(parent_map, start, target)
                return path, nodes_explored, True
            
            for neighbor, cost in grid.get_neighbors(current):
                if (neighbor.row, neighbor.col) not in visited:
                    visited.add((neighbor.row, neighbor.col))
                    parent_map[(neighbor.row, neighbor.col)] = (current.row, current.col)
                    queue.append(neighbor)
                    if callback:
                        callback('frontier', neighbor)
        
        return None, nodes_explored, False
    
    @staticmethod
    def dfs(grid, start, target, callback=None):
        stack = []
        visited = set()
        parent_map = {}
        
        start_node = grid.grid[start[0]][start[1]]
        stack.append(start_node)
        visited.add((start_node.row, start_node.col))
        parent_map[(start_node.row, start_node.col)] = None
        
        nodes_explored = 0
        
        while stack:
            current = stack.pop()
            nodes_explored += 1
            
            if callback:
                should_continue = callback('explore', current)
                if not should_continue:
                    return None, nodes_explored, False
            
            if (current.row, current.col) == target:
                path = SearchAlgorithms._reconstruct_path(parent_map, start, target)
                return path, nodes_explored, True
            
            neighbors = grid.get_neighbors(current)
            for neighbor, cost in reversed(neighbors):
                if (neighbor.row, neighbor.col) not in visited:
                    visited.add((neighbor.row, neighbor.col))
                    parent_map[(neighbor.row, neighbor.col)] = (current.row, current.col)
                    stack.append(neighbor)
                    if callback:
                        callback('frontier', neighbor)
        
        return None, nodes_explored, False
    
    @staticmethod
    def ucs(grid, start, target, callback=None):
        pq = PriorityQueue()
        visited = set()
        parent_map = {}
        cost_map = {}
        
        start_node = grid.grid[start[0]][start[1]]
        pq.put((0, 0, start_node))
        cost_map[(start_node.row, start_node.col)] = 0
        parent_map[(start_node.row, start_node.col)] = None
        
        counter = 1
        nodes_explored = 0
        
        while not pq.empty():
            current_cost, _, current = pq.get()
            
            if (current.row, current.col) in visited:
                continue
            
            visited.add((current.row, current.col))
            nodes_explored += 1
            
            if callback:
                should_continue = callback('explore', current)
                if not should_continue:
                    return None, nodes_explored, False
            
            if (current.row, current.col) == target:
                path = SearchAlgorithms._reconstruct_path(parent_map, start, target)
                return path, nodes_explored, True
            
            for neighbor, edge_cost in grid.get_neighbors(current):
                neighbor_pos = (neighbor.row, neighbor.col)
                if neighbor_pos not in visited:
                    new_cost = current_cost + edge_cost
                    if neighbor_pos not in cost_map or new_cost < cost_map[neighbor_pos]:
                        cost_map[neighbor_pos] = new_cost
                        parent_map[neighbor_pos] = (current.row, current.col)
                        pq.put((new_cost, counter, neighbor))
                        counter += 1
                        if callback:
                            callback('frontier', neighbor)
        
        return None, nodes_explored, False
    
    @staticmethod
    def dls(grid, start, target, depth_limit=15, callback=None):
        start_node = grid.grid[start[0]][start[1]]
        parent_map = {(start_node.row, start_node.col): None}
        nodes_explored = 0
        
        def dls_recursive(node, depth, visited_path):
            nonlocal nodes_explored
            nodes_explored += 1
            
            if callback:
                should_continue = callback('explore', node)
                if not should_continue:
                    return None, False
            
            if (node.row, node.col) == target:
                path = SearchAlgorithms._reconstruct_path(parent_map, start, target)
                return path, True
            
            if depth >= depth_limit:
                return None, False
            
            for neighbor, cost in grid.get_neighbors(node):
                neighbor_pos = (neighbor.row, neighbor.col)
                if neighbor_pos not in visited_path:
                    visited_path.add(neighbor_pos)
                    parent_map[neighbor_pos] = (node.row, node.col)
                    
                    if callback:
                        callback('frontier', neighbor)
                    
                    result, found = dls_recursive(neighbor, depth + 1, visited_path)
                    if found:
                        return result, True
                    
                  
                    visited_path.remove(neighbor_pos)
                    del parent_map[neighbor_pos]
            
            return None, False
        
        visited = {(start_node.row, start_node.col)}
        path, found = dls_recursive(start_node, 0, visited)
        return path, nodes_explored, found
    
    @staticmethod
    def iddfs(grid, start, target, max_depth=30, callback=None):
        total_nodes_explored = 0
        
        for depth_limit in range(max_depth):
            if callback:
                callback('depth_update', depth_limit)
            
            result = SearchAlgorithms.dls(grid, start, target, depth_limit, callback)
            if result[2]:  
                return result[0], result[1] + total_nodes_explored, True
            total_nodes_explored += result[1]
        
        return None, total_nodes_explored, False
    
    @staticmethod
    def bidirectional(grid, start, target, callback=None):
        forward_queue = deque()
        forward_visited = {}
        forward_parent = {}
        
        backward_queue = deque()
        backward_visited = {}
        backward_parent = {}
        
        start_node = grid.grid[start[0]][start[1]]
        target_node = grid.grid[target[0]][target[1]]
        
        forward_queue.append(start_node)
        forward_visited[start] = start_node
        forward_parent[start] = None
        
        backward_queue.append(target_node)
        backward_visited[target] = target_node
        backward_parent[target] = None
        
        nodes_explored = 0
        
        while forward_queue or backward_queue:
            if forward_queue:
                current = forward_queue.popleft()
                current_pos = (current.row, current.col)
                nodes_explored += 1
                
                if callback:
                    should_continue = callback('explore', current)
                    if not should_continue:
                        return None, nodes_explored, False
                
                if current_pos in backward_visited:
                    forward_path = SearchAlgorithms._reconstruct_path(forward_parent, start, current_pos)
                    backward_path = SearchAlgorithms._reconstruct_path(backward_parent, target, current_pos)
                    full_path = forward_path + list(reversed(backward_path[:-1]))
                    return full_path, nodes_explored, True
                
                for neighbor, cost in grid.get_neighbors(current):
                    neighbor_pos = (neighbor.row, neighbor.col)
                    if neighbor_pos not in forward_visited:
                        forward_visited[neighbor_pos] = neighbor
                        forward_parent[neighbor_pos] = current_pos
                        forward_queue.append(neighbor)
                        if callback:
                            callback('frontier', neighbor)
            
            if backward_queue:
                current = backward_queue.popleft()
                current_pos = (current.row, current.col)
                nodes_explored += 1
                
                if callback:
                    should_continue = callback('explore', current)
                    if not should_continue:
                        return None, nodes_explored, False
                
                if current_pos in forward_visited:
                    forward_path = SearchAlgorithms._reconstruct_path(forward_parent, start, current_pos)
                    backward_path = SearchAlgorithms._reconstruct_path(backward_parent, target, current_pos)
                    full_path = forward_path + list(reversed(backward_path[:-1]))
                    return full_path, nodes_explored, True
                
                for neighbor, cost in grid.get_neighbors(current):
                    neighbor_pos = (neighbor.row, neighbor.col)
                    if neighbor_pos not in backward_visited:
                        backward_visited[neighbor_pos] = neighbor
                        backward_parent[neighbor_pos] = current_pos
                        backward_queue.append(neighbor)
                        if callback:
                            callback('frontier', neighbor)
        
        return None, nodes_explored, False
    
    @staticmethod
    def _reconstruct_path(parent_map, start, target):
        path = []
        current = target
        while current is not None:
            path.append(current)
            current = parent_map.get(current)
        path.reverse()
        return path